### INSTALLATION
* drop the GearGame folder in your GOW3 game folder (BASE FOLDERS)
* drop the TU6 files in 4D5308AB\000B0000 (TITLE UPDATE 6 FOLDERS)

### NOTES
- FOR THE ULTRAWIDE FIX, USE THE 21:9 PATCH FOR THE GAME.
- YOU CANNOT USE THE BASE VERSION FILES WITH THE TITLE UPDATE AT THE SAME TIME.
- The TU6 files can be combined in the same folder.
- Also backup the original files if you want to play on TU6.

### CREDITS
TudorHorse for finding the Improved Performance fix.
Sowa_95 for the FOV code.
bomabomaboma for the Ultrawide Patch.