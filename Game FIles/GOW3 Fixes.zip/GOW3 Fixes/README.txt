drop the GearGame folder in your GOW3 game folder (BASE VERSION)
drop the Title Update files in 4D5308AB\000B0000 (TITLE UPDATE 6)
btw the TU6 files can be combined in the same folder

YOU CANNOT USE THE BASE VERSION FILES WITH THE TITLE UPDATE AT THE SAME TIME.
also backup the original files if you want to play on TU6

Credits to TudorHorse/Sowa_95 for finding this fix. :)