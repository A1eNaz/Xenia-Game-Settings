v1 - disabled Lens Flare, AF x16
v2 - unlimited FPS, disabled Lens Flare, AF x16

place one of the 2 files from their folders in BmGame/CookedXenon

Credits to Sowa_95. :)