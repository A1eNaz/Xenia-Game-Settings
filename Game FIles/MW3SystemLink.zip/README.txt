drop the plugin in the Netplay Folder
allow_plugins = true in the config