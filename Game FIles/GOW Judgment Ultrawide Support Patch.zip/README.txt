These ini changes will eliminate the UI issues that Gears of War Judgment has when the "21:9 Aspect Ratio Support Patch" is enabled.


For the BASE Disc version of the game:
drop the GearGame folder in your GOWJ game folder (BASE FOLDERS)
also enable "Disable Coalesced Hash Check" patch so that the Dirty Disc UI doesn't pop-up when starting the game.

For the Title Update 6 (TU4) version:
drop the TU6 files in 4D530A26\000B0000 (TITLE UPDATE 6 FOLDERS)

All original, unmodified BASE game files are also provided in case you'd need to uninstall.

YOU CANNOT USE THE BASE VERSION FILES WITH THE TITLE UPDATE AT THE SAME TIME.
