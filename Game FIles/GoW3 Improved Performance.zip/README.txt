drop the GearGame folder in your GoW3 game folder

Credits to TudorHorse for finding this fix. :)