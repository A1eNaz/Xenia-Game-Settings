Drop the Skip Intro files into your game folder and replace the existing files (you should also back up the original files just in case)

Drop the Extended FOV + No Motion Blur files into your game folder and replace the existing files (you should also back up the original files just in case)

credits to BFBC2 Toolkit and Battlefield Modding for making this possible. :D

their server is located here: https://discord.com/invite/MVSeAVUvQ9