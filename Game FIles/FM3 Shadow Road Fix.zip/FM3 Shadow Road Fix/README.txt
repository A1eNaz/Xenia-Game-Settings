the Shadow Road Fix folder gets placed in the game's folder.
the DLC Shadow Road Fix folder gets placed in Xenia's Folder.
replace any files if the prompt appears.

credits to Omegasis for the fix.