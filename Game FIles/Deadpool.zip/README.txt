drop one of the TransGame folders in your Deadpool folder
Credits to Sowa_95