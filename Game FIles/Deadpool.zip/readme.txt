v1 - disabled Lens Flare, unlimited FPS, disabled FXAA, adjusted HighDef3D.
v2 - all of the above + disabled DoF, which also changes original color grading. This will let you play the game on Vulkan if needed.

- By Sowa_95