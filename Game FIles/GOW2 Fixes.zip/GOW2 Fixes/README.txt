drop the Title Update files in 4D53082D\000B0000 (TITLE UPDATE 6)
btw the TU6 files can be in the same folder

Credits to TudorHorse/Sowa_95 for finding this fix. :)