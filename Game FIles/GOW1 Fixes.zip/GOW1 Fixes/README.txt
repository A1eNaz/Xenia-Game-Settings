drop the Title Update files in 4D5307D5\000B0000 (TITLE UPDATE 5)
btw the TU5 files can be in the same folder

Credits to TudorHorse/Sowa_95 for finding this fix. :)